function mostrarTabla1() {
    document.getElementById('tabla1').style.display = 'block';
    document.getElementById('tabla2').style.display = 'none';
}

function mostrarTabla2() {
    document.getElementById('tabla1').style.display = 'none';
    document.getElementById('tabla2').style.display = 'block';
}
